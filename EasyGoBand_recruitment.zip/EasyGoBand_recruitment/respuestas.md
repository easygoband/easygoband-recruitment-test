# Instrucciones y documentación
Para ejecutar el programa unicamente es necesario disponer de un interprete de **Python**. El comando a ejecutar es: *py src/main.py*.
## Explicación
El código en python realiza una petición GET a la API de EasyGoBand, recibe los objetos en formate JSON y los almacena en una base de datos SQLite. Posteriormente se acriva el servidor web, que atiende a las peticiones GET de la web. **NOTA:** El filtrado por sesiones se realiza en el *backend*. La base de datos se genera tras la primera ejecución y pude ser encontrada en *src/storage/data.db*.

### Arquitectura:
![Alt text](./architecture.jpg?raw=true "Architecture")

### SQL:
![Alt text](./database.jpg?raw=true "DataBase")

# Respuestas
### ¿Has aplicado los principios SOLID?
Si. He aplicado el *principio de responsabilidad unica* para separar el codigo en base a sus funcionalidades y el *principio abierto/cerrado* a la hora de extender la funcionalidad del codigo. El resto de principios considero que no son evaluables dado que el alcance del codígo es bastante pequeño

### ¿Cuánto tiempo has estado pensando y escribiendo los tests del código? Si hubieras tenido mucho más tiempo... ¿que habrías añadido?
Debido a que no he dispuesto de mucho tiempo para realizar el programa no me ha sido posible implementar tests. De haber tenido mas tiempo me habría gustado implementar tests unitarios y mas adelante de integración.

### ¿Por qué motivo has elegido el lenguaje que has usado para este test?
He elegido Python debido a que es un lenguaje muy potente, versátil y poco verboso. Esto último añadido a la gran cantidad de librerías y comunidad existentes han sido el principal motivo de su elección dado el estrecho margen de tiempo del que he dispusto para realizar el programa.

### ¿Cómo mejorarías la API que has usado?
Añadiría la posibilidad de realizar peticiones POST/PUT para editar/añadir datos

### ¿Qué framework y lenguaje crees que se ha usado para exponer esta API REST? Consejo: En el protocolo HTTP viaja mucha información
He encontrado la cabecera  *{'x-powered-by': 'Express'}*, lo que me lleva a pensar que se ha utilizado express js

### ¿Crees que esta API soporta peticiones CORS? ¿Cómo has llegado a esa conclusión?
No he visto que se encontrasen las cabeceras *Access-Control-Allow*, por lo que deduzco que la API no soporta peticiones CORS

### ¿En qué infraestructura crees que está alojada la API? ¿Por qué crees que hemos tomado esa decisión?
Examinando la URL y las cabeceras, se puede saber que la API se aloja en *AWS (Amazon Web Services)*. Creo que se ha decidido externalizar el alojamiento de la API para abaratar costes de mantenimiento de servidores y para abstraerse de la administración del servidor. En mi opinión se ha elegido AWS para esta externalización debido a su fiabilidad, disponibilidad, escalabilidad, accesibilidad y probablemente coste competitivo

### ¿Cómo rastrearías un problema de rendimiento en producción? ¿Alguna vez has tenido que hacerlo?
Nunca he tenido que hacerlo, pero creo que para rastrear un problema de estas características es importante disponer de la mayor cantidad de información (logs) de monitorización del sistema. Porbablemente estudiaria la posibilidad de volcar e interpretar los datos mediante una abse de datos no relacional

### Descríbete a ti mismo usando JSON.
```json
{
    "nombre": "Javier",
    "apellidos": "del Campo Robles",
    "edad": 23,
    "altura": 180,
    "peso": 85,
    "formacion" : {
        "principal": "Grado en Ingeniería Infomática",
        "especialización": "Ingeniería de computadores"
    },
    "experiencia": ["IoTsnes", "Consum", "Profesor de judo (5/6 primaria)", "Profesor de robótica (5/6 primaria)"],
    "conocimientos": {
        "programación": ["C","C++","C#","PHP","Js","HTML","CSS","Java","Python","Bash"],
        "idiomas":["Castellano", "Valenciano", "Ingles"]
    },
    "habilidades": [
        "Trabajo en equipo",
        "Solución de conflictos",
        "Planificación y organización",
        "Autoaprendizaje"
    ],
    "intereses": {
        "Deporte": ["Judo", "Baloncesto", "Running", "Pesca", "Ciclismo"],
        "Tecnología": ["Arduino", "Modificación/reparación de consolas", "Construcción de PCs"],
        "Ocio": ["Peliculas", "Series", "Videojuegos"],
        "Otros": ["Modelismo", "Historia"]
    }
}
```