var sessionsImages = {
    "19":"abono.png",
    "20": "diarios.png",
    "21": "diarios.png",
    "22": "diarios.png",
    "23": "vip.png",
    "24": "vip.png",
    "25": "vip.png",
    "26": "vip.png",
    "27": "premium.png",
    "28": "premium.png",
    "29": "premium.png",
    "30": "premium.png",
    "31": "acreditados.png",
    "32": "parking.png",
    "38": "prensa.png",
    "39": "autobus.png",
    "40": "autobus.png",
    "41": "autobus.png",
    "42": "autobus.png"
}

$(document).ready(function () {
    getAllSessions();
    getAllAccessProviders();
});

function getAllSessions() {
    $.ajax({
        type: "GET",
        url: "/api/getAllSessions",
        contentType: "application/json; charset=utf-8",
        success: function(data){
            //console.log(data);
            for(session in data) {
                let sName   = data[session]["name"];
                let sId     = data[session]["id"];
                $("#filter").append(`<option value='${sId}'>${sName}</option>`);
            } 
        },
    });
}

function getAllAccessProviders() {
    $.ajax({
        type: "GET",
        url: "/api/getAllAccessProviders",
        contentType: "application/json; charset=utf-8",
        success: function(data){
            //console.log(data);
            populatePage(data);  
        },
    });
}

function getAccessProvidersBySession() {
    let session = $("#filter").val();
    if(session < 0){
        getAllAccessProviders()
    } else {
        $.ajax({
            type: "GET",
            url: "/api/getAccessProvidersBySession?session="+session,
            contentType: "application/json; charset=utf-8",
            success: function(data){
                //console.log(data);
                populatePage(data);  
            },
        });
    }
}

function populatePage(data) {
    $("#content").html("");
    for(i in data) {
        let apSessions      = "";
        let totalUses       = data[i]["total_uses"];
        let apGroup         = data[i]["access_group_name"];
        let apModified_date = data[i]["modified"].split("T")[0];
        let apModified_time = data[i]["modified"].split("T")[1];
        let apName          = data[i]["name"].concat(" ").padEnd(35, '-');
        let image           = sessionsImages[data[i]["sessions"][0]["id"]];

        for(j in data[i]["sessions"]){
            apSessions += `<br>&nbsp;&nbsp;${data[i]["sessions"][j]["name"]}`;
        }
        let accessProviderHtml = 
            `<div class="column">
            <div class="content">
            <img src="img/${image}" alt="icon" style="width:100%">
            <h4>${apName}</h4>
            <p><strong>Total uses: </strong>${totalUses}</p>
            <p><strong>Access group:</strong>
                <br>&nbsp;&nbsp;${apGroup}
            </p>
            <p><strong>Last modified:</strong>
                <br>&nbsp;&nbsp;${apModified_date}
                <br>&nbsp;&nbsp;${apModified_time}
            </p>
            <p><strong>Sessions:</strong>${apSessions}</p>
            </div>
            </div>`;

        $("#content").append(accessProviderHtml);
    }
}