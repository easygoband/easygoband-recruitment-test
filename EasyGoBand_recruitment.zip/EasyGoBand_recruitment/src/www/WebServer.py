import http.server
import socketserver
import json         # To manage data as a JSON
from storage.MyDataBase     import MyDataBase

class MyHttpRequestHandler(http.server.SimpleHTTPRequestHandler):
    database = None

    def do_GET(self):
        # REQUEST HANDLERS
        self.path = "./www" + self.path
        if self.path == './www/':
            self.path = './www/html/index.html'
            return http.server.SimpleHTTPRequestHandler.do_GET(self)

        elif self.path.startswith('./www/html/'):
            return http.server.SimpleHTTPRequestHandler.do_GET(self)
        
        elif self.path.startswith('./www/img/'):
            return http.server.SimpleHTTPRequestHandler.do_GET(self)

        elif self.path.startswith('./www/css/'):
            return http.server.SimpleHTTPRequestHandler.do_GET(self)

        elif self.path.startswith('./www/js/'):
            return http.server.SimpleHTTPRequestHandler.do_GET(self)


        # REST HANDLERS
        elif self.path == './www/api/getAllSessions':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(self.database.getAllSessions(), ensure_ascii=True).encode('gbk'))

        elif self.path == './www/api/getAllAccessProviders':
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(self.database.getAllAcessProviders(), ensure_ascii=True).encode('gbk'))

        elif self.path.startswith('./www/api/getAccessProvidersBySession?session='):
            session = self.path.split("=")[1]
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps(self.database.getAcessProvidersBySession(session), ensure_ascii=True).encode('gbk'))

        

def startWebServer(hostName, serverPort, myDataBase: MyDataBase):
    handler = MyHttpRequestHandler
    handler.database = myDataBase
    my_server = socketserver.TCPServer((hostName, serverPort), handler)
    print("Server started at http://%s:%s" % (hostName, serverPort))

    try:
        my_server.serve_forever()
    except KeyboardInterrupt:
        pass

    my_server.server_close()
    print("Server stopped.")