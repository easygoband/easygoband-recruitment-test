import sqlite3

class MyDataBase:
    def __init__(self, dataBaseName):
        try:
            self.dataBaseName = dataBaseName
            sqliteConnection  = sqlite3.connect(dataBaseName)
            cursor = sqliteConnection.cursor()

            access_providers_table_query = '''CREATE TABLE access_providers(
                access_group_name TEXT,
                access_group_id INTEGER,
                total_uses INTEGER,
                event_id INTEGER,
                structure_decode BIT,
                name TEXT,
                modified TEXT,
                id INTEGER PRIMARY KEY,
                basic_product_id INTEGER);'''

            sessions_table_query = '''CREATE TABLE sessions(
                name TEXT,
                id INTEGER PRIMARY KEY);'''

            ap_sessions_table_query = '''CREATE TABLE ap_sessions(
                session_id INTEGER,
                ap_id INTEGER,
                FOREIGN KEY(session_id) REFERENCES sessions(id),
                FOREIGN KEY(ap_id) REFERENCES access_providers(id));'''
            
            cursor.execute(access_providers_table_query)
            cursor.execute(sessions_table_query)
            cursor.execute(ap_sessions_table_query)
            sqliteConnection.commit()

        except sqlite3.Error as error:
            print("[SQL] Error while creating the tables", error)

        finally:
            if sqliteConnection:
                sqliteConnection.close()
                #print("[SQL] SQLite connection is closed")
    
    def putAcessProviders(self, accessProviders):
        try:
            for accessProvider in accessProviders:
                sqliteConnection  = sqlite3.connect(self.dataBaseName)
                cursor = sqliteConnection .cursor()
                access_provider_query = '''INSERT OR REPLACE INTO access_providers VALUES (?,?,?,?,?,?,?,?,?)'''
                access_provider_data = (
                    accessProvider["access_group_name"],
                    accessProvider["access_group_id"],
                    accessProvider["total_uses"],
                    accessProvider["event_id"],
                    accessProvider["structure_decode"],
                    accessProvider["name"],
                    accessProvider["modified"],
                    accessProvider["id"],
                    accessProvider["basic_product_id"]
                )
                cursor.execute(access_provider_query, access_provider_data)

                for session in accessProvider["sessions"]:
                    ap_sessions_query   = '''INSERT OR REPLACE INTO ap_sessions VALUES (?,?)'''
                    ap_sessions_data    = (session["id"], accessProvider["id"])
                    sessions_query      = '''INSERT OR REPLACE INTO sessions VALUES (?,?)'''
                    sessions_data       = (session["name"], session["id"])

                    cursor.execute(sessions_query, sessions_data)
                    cursor.execute(ap_sessions_query, ap_sessions_data)
                

                sqliteConnection.commit()
                cursor.close()
        
        except sqlite3.Error as error:
            print("[SQL] Failed to insert Python variable into sqlite table", error)
        
        finally:
            if sqliteConnection :
                sqliteConnection.close()
                #print("[SQL] The SQLite connection is closed")


    # def putAcessProvider(self, accessProvider):
    #     try:
    #         sqliteConnection  = sqlite3.connect(self.dataBaseName)
    #         cursor = sqliteConnection .cursor()
    #         access_provider_query = '''INSERT OR REPLACE INTO access_providers VALUES (?,?,?,?,?,?,?,?,?)'''
    #         access_provider_data = (
    #             accessProvider.accessGroupName,
    #             accessProvider.accessGroupID,
    #             accessProvider.totalUses,
    #             accessProvider.eventID,
    #             accessProvider.structureDecode,
    #             accessProvider.name,
    #             accessProvider.modified,
    #             accessProvider.id,
    #             accessProvider.basicProductID
    #         )
    #         cursor.execute(access_provider_query, access_provider_data)

    #         for session in accessProvider.sessions:
    #             ap_sessions_query   = '''INSERT OR REPLACE INTO ap_sessions VALUES (?,?)'''
    #             ap_sessions_data    = (session.id, accessProvider.id)
    #             sessions_query      = '''INSERT OR REPLACE INTO sessions VALUES (?,?)'''
    #             sessions_data       = (session.name, session.id)

    #             cursor.execute(sessions_query, sessions_data)
    #             cursor.execute(ap_sessions_query, ap_sessions_data)
            

    #         sqliteConnection.commit()
    #         cursor.close()
        
    #     except sqlite3.Error as error:
    #         print("[SQL] Failed to insert Python variable into sqlite table", error)
        
    #     finally:
    #         if sqliteConnection :
    #             sqliteConnection.close()
    #             #print("[SQL] The SQLite connection is closed")


    def getAllAcessProviders(self):
        try:
            accessProviders = []

            sqliteConnection  = sqlite3.connect(self.dataBaseName)
            cursor = sqliteConnection.cursor()

            acces_providers_query = """SELECT * from access_providers"""
            sessions_query = '''SELECT sessions.*
                FROM sessions
                JOIN ap_sessions ON sessions.id = ap_sessions.session_id
                WHERE ap_sessions.ap_id = ?'''

            cursor.execute(acces_providers_query)
            queryResult = cursor.fetchall()        
            for accessProvider in queryResult:
                sessions = []
                cursor.execute(sessions_query, (accessProvider[7],))
                queryResult2 = cursor.fetchall()
                for session in queryResult2:
                    sessions.append({"name": session[0], "id": session[1]}) 

                accessProviders.append(
                    {
                        "access_group_name" : accessProvider[0],
                        "access_group_id"   : accessProvider[1],
                        "total_uses"        : accessProvider[2],
                        "event_id"          : accessProvider[3],
                        "structure_decode"  : accessProvider[4],
                        "name"              : accessProvider[5],
                        "modified"          : accessProvider[6],
                        "id"                : accessProvider[7],
                        "basic_product_id"  : accessProvider[8],
                        "sessions"          : sessions
                    }
                )
                
            cursor.close()
              
        except sqlite3.Error as error:
            print("[SQL] Failed to read an access provider", error)
        
        finally:
            if sqliteConnection :
                sqliteConnection.close()
                #print("[SQL] The SQLite connection is closed")
            return accessProviders

    def getAllSessions(self):
        try:
            sessions = []

            sqliteConnection  = sqlite3.connect(self.dataBaseName)
            cursor = sqliteConnection.cursor()

            sessions_query = """SELECT * from sessions"""
            cursor.execute(sessions_query)
            queryResult = cursor.fetchall()        
            for session in queryResult:
                sessions.append(
                    {
                        "name"  : session[0],
                        "id"    : session[1]
                    }
                )

            cursor.close()
              
        except sqlite3.Error as error:
            print("[SQL] Failed to read a session", error)
        
        finally:
            if sqliteConnection :
                sqliteConnection.close()
                #print("[SQL] The SQLite connection is closed")
            return sessions


    def getAcessProvidersBySession(self, sessionID):
        try:
            accessProviders = []

            sqliteConnection  = sqlite3.connect(self.dataBaseName)
            cursor = sqliteConnection.cursor()

            acces_providers_query = '''SELECT access_providers.*
                FROM access_providers
                JOIN ap_sessions ON access_providers.id = ap_sessions.ap_id
                WHERE ap_sessions.session_id = ?'''
             
            sessions_query = '''SELECT sessions.*
                FROM sessions
                JOIN ap_sessions ON sessions.id = ap_sessions.session_id
                WHERE ap_sessions.ap_id = ?'''

            cursor.execute(acces_providers_query, (sessionID,))
            queryResult = cursor.fetchall()        
            for accessProvider in queryResult:
                sessions = []
                cursor.execute(sessions_query, (accessProvider[7],))
                queryResult2 = cursor.fetchall()
                for session in queryResult2:
                    sessions.append({"name": session[0], "id": session[1]}) 

                accessProviders.append(
                    {
                        "access_group_name" : accessProvider[0],
                        "access_group_id"   : accessProvider[1],
                        "total_uses"        : accessProvider[2],
                        "event_id"          : accessProvider[3],
                        "structure_decode"  : accessProvider[4],
                        "name"              : accessProvider[5],
                        "modified"          : accessProvider[6],
                        "id"                : accessProvider[7],
                        "basic_product_id"  : accessProvider[8],
                        "sessions"          : sessions
                    }
                )
                
            cursor.close()
              
        except sqlite3.Error as error:
            print("[SQL] Failed to read an access provider", error)
        
        finally:
            if sqliteConnection :
                sqliteConnection.close()
                #print("[SQL] The SQLite connection is closed")
            return accessProviders

            
    
    # def getAcessProvidersBySession(self, sessionID):
    #     try:
    #         accessProviders = []

    #         sqliteConnection  = sqlite3.connect(self.dataBaseName)
    #         cursor = sqliteConnection.cursor()

    #         acces_providers_query = '''SELECT access_providers.*
    #             FROM access_providers
    #             JOIN ap_sessions ON access_providers.id = ap_sessions.ap_id
    #             WHERE ap_sessions.session_id = ?'''
    #         cursor.execute(acces_providers_query, (sessionID,))
    #         queryResult = cursor.fetchall()        
    #         for accessProvider in queryResult:
    #             ap = AccessProvider()
    #             ap.accessGroupName  = accessProvider[0]
    #             ap.accessGroupID    = accessProvider[1]
    #             ap.totalUses        = accessProvider[2]
    #             ap.eventID          = accessProvider[3]
    #             ap.structureDecode  = accessProvider[4]
    #             ap.name             = accessProvider[5]
    #             ap.modified         = accessProvider[6]
    #             ap.id               = accessProvider[7]
    #             ap.basicProductID   = accessProvider[8]
    #             ap.sessions         = []
    #             accessProviders.append(ap)

    #         for accessProvider in accessProviders:
    #             sessions_query = '''SELECT sessions.*
    #                 FROM sessions
    #                 JOIN ap_sessions ON sessions.id = ap_sessions.session_id
    #                 WHERE ap_sessions.ap_id = ?'''
    #             cursor.execute(sessions_query, (accessProvider.id, ))
    #             queryResult = cursor.fetchall()
    #             for session in queryResult:
    #                 s = Session()
    #                 s.name = session [0]
    #                 s.id   = session [1]
    #                 accessProvider.sessions.append(s)                

    #         cursor.close()
              
    #     except sqlite3.Error as error:
    #         print("[SQL] Failed to read an access provider", error)
        
    #     finally:
    #         if sqliteConnection :
    #             sqliteConnection.close()
    #             #print("[SQL] The SQLite connection is closed")
    #         return accessProviders




