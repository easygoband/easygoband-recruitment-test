#import requests     # To get data from EasyGoBand's URL
import json         # To manage data as a JSON
import os           # To erase DB on every execution
import webbrowser   # To open system webbrowser
import sys
import subprocess

import lib.requests.__init__ as requests
from storage.MyDataBase     import MyDataBase
from www.WebServer          import startWebServer

URL         = "https://pnny0h3cuf.execute-api.eu-west-1.amazonaws.com/dev/providers/{}"
EVENT_ID    = 1
AUTH_HEADER = {"Authorization": "Basic cJmAc71jah17sgqi1jqaksvaksda="}


if __name__ == "__main__":

    #subprocess.check_call([sys.executable, '-m', 'pip', 'install', 'requests'])
    print("\n-----------------------------------")
    print("EasyGoBand recruitment test program")
    print("-----------------------------------")

    # Server connection and data obtaining
    print("Connecting to " + URL.format(EVENT_ID))
    try:
        response = requests.get(URL.format(EVENT_ID), headers = AUTH_HEADER) #TODO add TRY to manage no connection
        print(response.headers)
        exit()#dev
    except:
        print("Connection ERROR")
        exit()
    data = json.loads(response.content)
    print("Connection {}. Elements obtained = {}".format("success" if len(data)>0 else "ERROR", len(data)))

    # Add elements from the list to the database
    print("Saving data in the database")
    try:
        os.remove('src/storage/data.db')
    except:
        pass
    myDataBase = MyDataBase('src/storage/data.db')
    myDataBase.putAcessProviders(data)

    # Start the web server
    url  = "localhost"
    port = 8080
    webbrowser.open("http://{}:{}".format(url, port))
    startWebServer(url, port, myDataBase)